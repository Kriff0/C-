#include "Date.hpp"


bool date_valide(int& day, int& month, int& year){  // vérifie que la date existe
	if ((day>31 || day < 1) || (month>12 || month<1) || (year < 1) ){
		return false;  //date invalide
	}
	else {
		return true; //date valide
	}

}


bool bissextile(int year){
	if ( (year%400==0) || ( (year%100!=0) && (year%4==0) ) ){
		return true; // année bissextile
	}
	else{
		return false; // année non bissextile
	}
}


bool is_date(int jour,int mois,int annee){  //fonction qui vérifie si la date est valide ou non /// à compléter pour vérifier si la date n'est pas initialiser
	// éventuellement à modif car static ************************************
	//**hyp 1:sans argu
	int jour = Date::day();
	int mois = Date::month();
	int annee = Date::year();
	//*****
	test_validite = date_valide(jour, mois, annee);
	test_bissextile = bissextile(annee)
	if (test_validite == false) {  // si date non valide
		jour = 0;
		mois = 0;
		annee = 0;
		return false
	}
	else {
		if ((test_bissextile=false)){  // si date valide et année non bissextile
			if ((jour>28) & (mois==2)){ // si jour € [29/02, 31/02]
				jour = 0;
				mois = 0;
				annee = 0;
				return false
			}
			else {
				return true
			}
		}
		else{  // si date valide et année bissextile
			if ((jour>29) & (mois==2)){ //	si jour € [30/02, 31/02]
				jour = 0;
				mois = 0;
				annee = 0;
				return false
			}
			else {
				return true
			}
		}

	}
}

// accesseurs:
const int& day() const{return day;}	// renvoie l'attribut day
//premier const -> la méthode renvoie une référence constante sur l'entier désiré
//2e const -> la méthode day ne modifie pas les attributs de de la classe à l'appel de la méthode

const int& month() const{return month;}		// renvoie l'attribut month

const int& year() const{return year;}		// renvoie l'attribut year


Date from_string(const std::string& name){    // à modif   ******************
	// On sépare les chaines suivant le séparateur "/"
    string str_day = name.substr(0, name.find("/"));
    date_name = name.substr(name.find("/")+1);
    string str_month = name.substr(0, name.find("/"));
    string str_year= name.substr(name.find("/")+1);

    // Conversion en int
    day=stoi(str_day);
    month=stoi(str_month);
    year=stoi(str_year);
    return(is_date( day, month, year));
}

std::string to_string(const Date& date){
	int day = date::day();
	int month = Date::month();
	int year = Date::year();
	if (day<10){  // si jour est théoriquement à 1 chiffre
		//on vérifie si premier chiffre = 0
		//si oui, day = 2e chiffre
	}
	if (month<10){  // si jour est théoriquement à 1 chiffre
		//on vérifie si premier chiffre = 0
		//si oui, day = 2e chiffre
	}
	if (year<10){  // si jour est théoriquement à 1 chiffre ou 2 ou 3 ou 4
		//on vérifie si premier chiffre = 0
		//si oui, day = 2e chiffre
	}
}

