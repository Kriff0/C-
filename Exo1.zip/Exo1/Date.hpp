#ifndef DATE.H
#define DATE.H

#include<string>

class Date{

	//Attributs
	int jour;
	int mois;
	int annee;


	// Méthodes
	static bool is_date(int jour,int mois,int anne);		// vérifie si la date est valide et si elle ne l'est pas, date = 0/0/0
	// méthode statiques € classe mais pas aux objets instancés à partir de la calsse
	// ces fonctions n'ont pas accès aux attributs de la classe sauf les données statiques de l'objet
	// donc il faut enlever arguments
	static Date from_string(const std::string& name);
	const int& day() const;		// renvoie l'attribut day
	const int& month() const;		// renvoie l'attribut month
	const int& year() const;		// renvoie l'attribut year


};



#endif
