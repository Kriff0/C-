#include <iostream>


#include"Date.hpp"
#include"Date.cpp"
using namespace std;


int main()

{
 cout << "lololo" << endl;
    return 0;
    Date date1;





    return 0;
}


